-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for osx10.10 (x86_64)
--
-- Host: localhost    Database: ecommercedb
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `SequelizeMeta`
--

DROP TABLE IF EXISTS `SequelizeMeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SequelizeMeta` (
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SequelizeMeta`
--

LOCK TABLES `SequelizeMeta` WRITE;
/*!40000 ALTER TABLE `SequelizeMeta` DISABLE KEYS */;
INSERT INTO `SequelizeMeta` VALUES ('20251114164428-add_birthday_to_guest.cjs'),('20251114221255-add_avatar_to_guest.cjs'),('20251122000000-create-prelaunch-subscribers.cjs'),('20251123155512-add-type-campaign-to-sale-details.cjs'),('20251123160041-add-type-campaign-to-carts.cjs'),('20251124171415-add-home-to-source-enum.cjs'),('20251124174913-create-newsletter-subscribers.cjs'),('20251124174920-create-newsletter-campaigns.cjs'),('20251125000000-add-userId-to-newsletter-subscribers.cjs'),('20251125120817-add-preferences-to-newsletter-subscribers.cjs'),('20251125121102-add-campaign-type-to-newsletter-campaigns.cjs'),('20251125150145-create-postal-codes-table.cjs'),('20251125150935-seed-postal-codes-spain.cjs'),('20251128_create_retry_queue.cjs'),('20251128000000-create-printful-webhook-logs.cjs'),('20251128000001-add-tracking-fields-to-sales.cjs'),('20251128150000_create_analytics_cache.cjs'),('20251128150100_create_product_analytics.cjs'),('20251201000000-add-tracking-token-to-sales.cjs'),('20251208000000-create-prelaunch-config.cjs');
/*!40000 ALTER TABLE `SequelizeMeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_clients`
--

DROP TABLE IF EXISTS `address_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `surname` varchar(250) NOT NULL,
  `pais` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `zipcode` varchar(250) NOT NULL,
  `poblacion` varchar(250) NOT NULL,
  `ciudad` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(250) NOT NULL,
  `referencia` varchar(250) DEFAULT NULL,
  `nota` varchar(255) DEFAULT NULL,
  `birthday` varchar(20) DEFAULT NULL,
  `usual_shipping_address` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `address_clients_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_clients`
--

LOCK TABLES `address_clients` WRITE;
/*!40000 ALTER TABLE `address_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_guests`
--

DROP TABLE IF EXISTS `address_guests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_guests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `surname` varchar(250) NOT NULL,
  `pais` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `zipcode` varchar(250) NOT NULL,
  `poblacion` varchar(250) NOT NULL,
  `ciudad` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(250) NOT NULL,
  `referencia` varchar(250) DEFAULT NULL,
  `nota` varchar(255) DEFAULT NULL,
  `birthday` varchar(20) DEFAULT NULL,
  `usual_shipping_address` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `guest_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `guest_id` (`guest_id`),
  CONSTRAINT `address_guests_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_guests`
--

LOCK TABLES `address_guests` WRITE;
/*!40000 ALTER TABLE `address_guests` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_guests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_cache`
--

DROP TABLE IF EXISTS `analytics_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analytics_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único del registro de analytics',
  `metricType` enum('daily','weekly','monthly','yearly') NOT NULL COMMENT 'Tipo de agregación temporal',
  `date` date NOT NULL COMMENT 'Fecha de la métrica (inicio del período)',
  `revenue` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Revenue total del período',
  `costs` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Costos totales Printful (productos + envío)',
  `profit` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Ganancia neta (revenue - costs)',
  `margin` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Margen de ganancia en porcentaje',
  `orderCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Total de órdenes',
  `syncedCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Órdenes sincronizadas exitosamente',
  `pendingCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Órdenes pendientes de sync',
  `shippedCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Órdenes enviadas',
  `deliveredCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Órdenes entregadas',
  `failedCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Órdenes fallidas',
  `successRate` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Tasa de éxito en porcentaje',
  `avgFulfillmentTime` int(11) DEFAULT NULL COMMENT 'Tiempo promedio de fulfillment en horas',
  `productCosts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Desglose de costos por producto { productId: cost }' CHECK (json_valid(`productCosts`)),
  `shippingCosts` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Costos de envío totales',
  `avgOrderValue` decimal(10,2) DEFAULT NULL COMMENT 'Valor promedio de orden (AOV)',
  `customerStats` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Estadísticas de clientes { new, returning, users, guests }' CHECK (json_valid(`customerStats`)),
  `paymentMethods` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Revenue por método de pago { stripe: X, paypal: Y }' CHECK (json_valid(`paymentMethods`)),
  `topProducts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Top 10 productos del período [{ productId, revenue, units }]' CHECK (json_valid(`topProducts`)),
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Datos adicionales flexibles' CHECK (json_valid(`metadata`)),
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_analytics_metric_date` (`metricType`,`date`),
  KEY `idx_analytics_date` (`date`),
  KEY `idx_analytics_type` (`metricType`),
  KEY `idx_analytics_date_type` (`date`,`metricType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Cache de métricas agregadas para analytics dashboard';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_cache`
--

LOCK TABLES `analytics_cache` WRITE;
/*!40000 ALTER TABLE `analytics_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_discount` int(11) DEFAULT 1,
  `discount` float DEFAULT 0,
  `cantidad` int(11) NOT NULL,
  `code_cupon` varchar(255) DEFAULT NULL,
  `code_discount` varchar(255) DEFAULT NULL,
  `type_campaign` int(11) DEFAULT NULL,
  `price_unitario` varchar(255) NOT NULL,
  `subtotal` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `variedadId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `productId` (`productId`),
  KEY `variedadId` (`variedadId`),
  CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `carts_ibfk_3` FOREIGN KEY (`variedadId`) REFERENCES `variedades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartsCache`
--

DROP TABLE IF EXISTS `cartsCache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cartsCache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_status` varchar(255) DEFAULT NULL,
  `type_discount` int(11) DEFAULT 1,
  `discount` float DEFAULT 0,
  `cantidad` int(11) NOT NULL,
  `code_cupon` varchar(255) DEFAULT NULL,
  `code_discount` varchar(255) DEFAULT NULL,
  `price_unitario` varchar(255) NOT NULL,
  `subtotal` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `variedadId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `guest_id` (`guest_id`),
  KEY `productId` (`productId`),
  KEY `variedadId` (`variedadId`),
  CONSTRAINT `cartscache_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cartscache_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `cartscache_ibfk_3` FOREIGN KEY (`variedadId`) REFERENCES `variedades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartsCache`
--

LOCK TABLES `cartsCache` WRITE;
/*!40000 ALTER TABLE `cartsCache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cartsCache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `imagen` varchar(250) NOT NULL,
  `custom_image` varchar(250) DEFAULT NULL,
  `state` int(11) DEFAULT 1,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_conversations`
--

DROP TABLE IF EXISTS `chat_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT 'ID del usuario si está autenticado',
  `guest_id` int(11) DEFAULT NULL COMMENT 'ID del invitado si no está autenticado',
  `session_id` varchar(255) NOT NULL COMMENT 'ID de sesión único para identificar la conversación',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `status` enum('open','closed','pending') DEFAULT 'open',
  `last_message` text DEFAULT NULL,
  `last_message_time` datetime DEFAULT NULL,
  `unread_count` int(11) DEFAULT 0,
  `agent_id` varchar(255) DEFAULT NULL COMMENT 'ID del agente asignado',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_conversations`
--

LOCK TABLES `chat_conversations` WRITE;
/*!40000 ALTER TABLE `chat_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversation_id` int(11) NOT NULL,
  `sender_type` enum('user','agent','system') NOT NULL,
  `sender_id` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_id` (`conversation_id`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkout_cache`
--

DROP TABLE IF EXISTS `checkout_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkout_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `guestId` int(11) DEFAULT NULL,
  `cart` longtext NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `guestId` (`guestId`),
  CONSTRAINT `checkout_cache_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `checkout_cache_ibfk_2` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkout_cache`
--

LOCK TABLES `checkout_cache` WRITE;
/*!40000 ALTER TABLE `checkout_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkout_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cupones`
--

DROP TABLE IF EXISTS `cupones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cupones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `type_discount` int(11) NOT NULL DEFAULT 1,
  `discount` float NOT NULL,
  `type_count` int(11) NOT NULL DEFAULT 1,
  `num_use` int(11) DEFAULT NULL,
  `type_segment` int(11) NOT NULL DEFAULT 1,
  `state` int(11) NOT NULL DEFAULT 1,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cupones`
--

LOCK TABLES `cupones` WRITE;
/*!40000 ALTER TABLE `cupones` DISABLE KEYS */;
/*!40000 ALTER TABLE `cupones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cupones_categorie`
--

DROP TABLE IF EXISTS `cupones_categorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cupones_categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuponeId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cuponeId` (`cuponeId`),
  CONSTRAINT `cupones_categorie_ibfk_1` FOREIGN KEY (`cuponeId`) REFERENCES `cupones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cupones_categorie`
--

LOCK TABLES `cupones_categorie` WRITE;
/*!40000 ALTER TABLE `cupones_categorie` DISABLE KEYS */;
/*!40000 ALTER TABLE `cupones_categorie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cupones_product`
--

DROP TABLE IF EXISTS `cupones_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cupones_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuponeId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cuponeId` (`cuponeId`),
  CONSTRAINT `cupones_product_ibfk_1` FOREIGN KEY (`cuponeId`) REFERENCES `cupones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cupones_product`
--

LOCK TABLES `cupones_product` WRITE;
/*!40000 ALTER TABLE `cupones_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `cupones_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts`
--

DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_campaign` int(11) NOT NULL DEFAULT 1,
  `type_discount` int(11) NOT NULL DEFAULT 1,
  `discount` float NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `start_date_num` bigint(20) NOT NULL,
  `end_date_num` bigint(20) NOT NULL,
  `state` int(11) DEFAULT 1,
  `type_segment` int(11) DEFAULT 1,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts`
--

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts_categorie`
--

DROP TABLE IF EXISTS `discounts_categorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts_categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discountId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discountId` (`discountId`),
  CONSTRAINT `discounts_categorie_ibfk_1` FOREIGN KEY (`discountId`) REFERENCES `discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts_categorie`
--

LOCK TABLES `discounts_categorie` WRITE;
/*!40000 ALTER TABLE `discounts_categorie` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts_categorie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts_product`
--

DROP TABLE IF EXISTS `discounts_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discountId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discountId` (`discountId`),
  KEY `productId` (`productId`),
  CONSTRAINT `discounts_product_ibfk_1` FOREIGN KEY (`discountId`) REFERENCES `discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discounts_product_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts_product`
--

LOCK TABLES `discounts_product` WRITE;
/*!40000 ALTER TABLE `discounts_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idFile` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `url` text DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `mime_type` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `dpi` int(11) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `created` int(11) NOT NULL,
  `thumbnail_url` varchar(255) DEFAULT NULL,
  `preview_url` varchar(255) DEFAULT NULL,
  `visible` tinyint(1) NOT NULL,
  `is_temporary` tinyint(1) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `optionVarietyId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `varietyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `varietyId` (`varietyId`),
  CONSTRAINT `files_ibfk_1` FOREIGN KEY (`varietyId`) REFERENCES `variedades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galerias`
--

DROP TABLE IF EXISTS `galerias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galerias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(250) NOT NULL,
  `color` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `productId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `productId` (`productId`),
  CONSTRAINT `galerias_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galerias`
--

LOCK TABLES `galerias` WRITE;
/*!40000 ALTER TABLE `galerias` DISABLE KEYS */;
/*!40000 ALTER TABLE `galerias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guests`
--

DROP TABLE IF EXISTS `guests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `state` int(11) DEFAULT 1,
  `birthday` datetime DEFAULT NULL,
  `avatar` varchar(250) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guests`
--

LOCK TABLES `guests` WRITE;
/*!40000 ALTER TABLE `guests` DISABLE KEYS */;
/*!40000 ALTER TABLE `guests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inboxes`
--

DROP TABLE IF EXISTS `inboxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inboxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) NOT NULL,
  `body` text NOT NULL,
  `status` enum('unread','read') DEFAULT 'unread',
  `type` varchar(50) DEFAULT NULL,
  `sentAt` datetime DEFAULT NULL,
  `receivedAt` datetime DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `guestId` int(11) DEFAULT NULL,
  `replyToId` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `guestId` (`guestId`),
  KEY `replyToId` (`replyToId`),
  CONSTRAINT `inboxes_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `inboxes_ibfk_2` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `inboxes_ibfk_3` FOREIGN KEY (`replyToId`) REFERENCES `inboxes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inboxes`
--

LOCK TABLES `inboxes` WRITE;
/*!40000 ALTER TABLE `inboxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `inboxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_campaigns`
--

DROP TABLE IF EXISTS `newsletter_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL COMMENT 'Nombre interno de la campaña',
  `subject` varchar(500) NOT NULL COMMENT 'Asunto del email',
  `html_body` longtext NOT NULL COMMENT 'Contenido HTML del email',
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Filtros aplicados (source, utm, dateRange, segment)' CHECK (json_valid(`filters`)),
  `status` enum('draft','scheduled','sending','completed','failed') DEFAULT 'draft',
  `scheduled_at` datetime DEFAULT NULL COMMENT 'Fecha programada para envío',
  `sent_at` datetime DEFAULT NULL COMMENT 'Fecha real de envío',
  `total_recipients` int(11) DEFAULT 0,
  `sent_count` int(11) DEFAULT 0,
  `delivered_count` int(11) DEFAULT 0,
  `failed_count` int(11) DEFAULT 0,
  `opened_count` int(11) DEFAULT 0 COMMENT 'Emails abiertos (si hay tracking)',
  `clicked_count` int(11) DEFAULT 0 COMMENT 'Clicks en links (si hay tracking)',
  `created_by` int(11) DEFAULT NULL COMMENT 'ID del admin que creó la campaña',
  `test_emails` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Array de emails de prueba enviados' CHECK (json_valid(`test_emails`)),
  `error_log` text DEFAULT NULL COMMENT 'Log de errores durante el envío',
  `campaign_type` enum('novedades','promociones','prelaunch','general') NOT NULL DEFAULT 'general' COMMENT 'Tipo de campaña para filtrar por preferencias de usuarios',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `newsletter_campaigns_status` (`status`),
  KEY `newsletter_campaigns_created_at` (`createdAt`),
  KEY `newsletter_campaigns_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_campaigns`
--

LOCK TABLES `newsletter_campaigns` WRITE;
/*!40000 ALTER TABLE `newsletter_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletter_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_subscribers`
--

DROP TABLE IF EXISTS `newsletter_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL,
  `userId` varchar(255) DEFAULT NULL COMMENT 'ID del usuario autenticado (NULL para guests)',
  `session_id` varchar(100) DEFAULT NULL,
  `source` enum('home','footer','checkout','campaign_import','admin') DEFAULT 'home' COMMENT 'Indica de dónde proviene la suscripción',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `utm_source` varchar(100) DEFAULT NULL,
  `utm_medium` varchar(100) DEFAULT NULL,
  `utm_campaign` varchar(100) DEFAULT NULL,
  `status` enum('subscribed','unsubscribed','bounced') DEFAULT 'subscribed',
  `email_verified` tinyint(1) DEFAULT 0,
  `verification_token` varchar(100) DEFAULT NULL,
  `notified_campaign` tinyint(1) DEFAULT 0 COMMENT 'Indica si ya fue notificado en la última campaña',
  `coupon_sent` tinyint(1) DEFAULT 0 COMMENT 'Indica si ya recibió el cupón exclusivo',
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Preferencias de contenido y canales del suscriptor' CHECK (json_valid(`preferences`)),
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `newsletter_subscribers_email` (`email`),
  KEY `newsletter_subscribers_status` (`status`),
  KEY `newsletter_subscribers_source` (`source`),
  KEY `newsletter_subscribers_created_at` (`createdAt`),
  KEY `newsletter_subscribers_email_verified` (`email_verified`),
  KEY `newsletter_subscribers_user_id` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_subscribers`
--

LOCK TABLES `newsletter_subscribers` WRITE;
/*!40000 ALTER TABLE `newsletter_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletter_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `color` varchar(255) DEFAULT 'primary',
  `type` varchar(255) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `isRead` tinyint(1) DEFAULT 0,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `saleId` int(11) DEFAULT NULL,
  `shipmentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `saleId` (`saleId`),
  KEY `shipmentId` (`shipmentId`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`saleId`) REFERENCES `sales` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `notifications_ibfk_3` FOREIGN KEY (`shipmentId`) REFERENCES `shipments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idOption` varchar(255) NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`value`)),
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `varietyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `varietyId` (`varietyId`),
  CONSTRAINT `options_ibfk_1` FOREIGN KEY (`varietyId`) REFERENCES `variedades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postal_codes`
--

DROP TABLE IF EXISTS `postal_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postal_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(2) NOT NULL COMMENT 'Código ISO del país (ES, FR, DE, IT, PT, etc.)',
  `postal_code` varchar(10) NOT NULL COMMENT 'Código postal (formato según país)',
  `province` varchar(100) NOT NULL COMMENT 'Provincia / Estado / Región',
  `city` varchar(100) NOT NULL COMMENT 'Ciudad / Población / Municipio',
  `city_normalized` varchar(100) NOT NULL COMMENT 'Nombre normalizado de la ciudad (sin acentos, minúsculas)',
  `is_primary` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Si es la ciudad principal del código postal',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Si el registro está activo',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_country_postal_code_city` (`country`,`postal_code`,`city_normalized`),
  KEY `idx_country_postal_code` (`country`,`postal_code`),
  KEY `idx_province` (`province`),
  KEY `idx_city_normalized` (`city_normalized`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postal_codes`
--

LOCK TABLES `postal_codes` WRITE;
/*!40000 ALTER TABLE `postal_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `postal_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prelaunch_config`
--

DROP TABLE IF EXISTS `prelaunch_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prelaunch_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Si está habilitado el modo pre-lanzamiento',
  `launch_date` datetime DEFAULT NULL COMMENT 'Fecha y hora programada para el lanzamiento oficial',
  `updated_by` int(11) DEFAULT NULL COMMENT 'ID del admin que hizo el último cambio',
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prelaunch_config_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prelaunch_config`
--

LOCK TABLES `prelaunch_config` WRITE;
/*!40000 ALTER TABLE `prelaunch_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `prelaunch_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prelaunch_subscribers`
--

DROP TABLE IF EXISTS `prelaunch_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prelaunch_subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `source` enum('main_form','cta_final','home') DEFAULT 'main_form' COMMENT 'Indica de qué formulario proviene la suscripción',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `utm_source` varchar(100) DEFAULT NULL,
  `utm_medium` varchar(100) DEFAULT NULL,
  `utm_campaign` varchar(100) DEFAULT NULL,
  `status` enum('subscribed','unsubscribed','bounced') DEFAULT 'subscribed',
  `email_verified` tinyint(1) DEFAULT 0,
  `verification_token` varchar(100) DEFAULT NULL,
  `notified_launch` tinyint(1) DEFAULT 0 COMMENT 'Indica si ya fue notificado del lanzamiento',
  `coupon_sent` tinyint(1) DEFAULT 0 COMMENT 'Indica si ya recibió el cupón exclusivo',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `prelaunch_subscribers_email` (`email`),
  KEY `prelaunch_subscribers_status` (`status`),
  KEY `prelaunch_subscribers_source` (`source`),
  KEY `prelaunch_subscribers_created_at` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prelaunch_subscribers`
--

LOCK TABLES `prelaunch_subscribers` WRITE;
/*!40000 ALTER TABLE `prelaunch_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `prelaunch_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printful_webhook_logs`
--

DROP TABLE IF EXISTS `printful_webhook_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printful_webhook_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(100) NOT NULL COMMENT 'Tipo de evento: package_shipped, order_failed, etc.',
  `order_id` varchar(50) DEFAULT NULL COMMENT 'ID de la orden en Printful',
  `event_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Datos completos del webhook' CHECK (json_valid(`event_data`)),
  `processed` tinyint(1) DEFAULT 0 COMMENT 'Si el evento fue procesado correctamente',
  `processing_error` text DEFAULT NULL COMMENT 'Error si hubo problema al procesar',
  `received_at` datetime DEFAULT NULL COMMENT 'Timestamp de recepción',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `printful_webhook_logs_event_type` (`event_type`),
  KEY `printful_webhook_logs_order_id` (`order_id`),
  KEY `printful_webhook_logs_received_at` (`received_at`),
  KEY `printful_webhook_logs_processed` (`processed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printful_webhook_logs`
--

LOCK TABLES `printful_webhook_logs` WRITE;
/*!40000 ALTER TABLE `printful_webhook_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `printful_webhook_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productVariants`
--

DROP TABLE IF EXISTS `productVariants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productVariants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `variant_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `varietyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `varietyId` (`varietyId`),
  CONSTRAINT `productvariants_ibfk_1` FOREIGN KEY (`varietyId`) REFERENCES `variedades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productVariants`
--

LOCK TABLES `productVariants` WRITE;
/*!40000 ALTER TABLE `productVariants` DISABLE KEYS */;
/*!40000 ALTER TABLE `productVariants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_analytics`
--

DROP TABLE IF EXISTS `product_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único del registro',
  `productId` int(11) NOT NULL COMMENT 'ID del producto',
  `date` date NOT NULL COMMENT 'Fecha de las métricas',
  `unitsSold` int(11) NOT NULL DEFAULT 0 COMMENT 'Unidades vendidas en la fecha',
  `revenue` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Revenue generado por el producto',
  `printfulCost` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Costo total Printful del producto',
  `profit` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Ganancia neta del producto',
  `margin` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Margen de ganancia en porcentaje',
  `orderCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Número de órdenes que incluyen este producto',
  `failedCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Órdenes fallidas que incluyen este producto',
  `avgPrice` decimal(10,2) DEFAULT NULL COMMENT 'Precio promedio del producto',
  `topVariants` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Variantes más vendidas [{ variantId, units, revenue }]' CHECK (json_valid(`topVariants`)),
  `customerSegment` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Segmentación de clientes { users, guests }' CHECK (json_valid(`customerSegment`)),
  `conversionRate` decimal(5,2) DEFAULT NULL COMMENT 'Tasa de conversión si hay datos de vistas',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Datos adicionales flexibles' CHECK (json_valid(`metadata`)),
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_product_analytics_product_date` (`productId`,`date`),
  KEY `idx_product_analytics_date` (`date`),
  KEY `idx_product_analytics_product` (`productId`),
  KEY `idx_product_analytics_revenue` (`revenue`),
  KEY `idx_product_analytics_units` (`unitsSold`),
  CONSTRAINT `product_analytics_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Métricas de performance por producto';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_analytics`
--

LOCK TABLES `product_analytics` WRITE;
/*!40000 ALTER TABLE `product_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProduct` varchar(255) DEFAULT NULL,
  `title` varchar(250) NOT NULL,
  `slug` varchar(1000) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `price_soles` float NOT NULL,
  `price_usd` float NOT NULL,
  `portada` varchar(255) NOT NULL,
  `state` int(11) DEFAULT 1,
  `printful_ignored` tinyint(1) DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `description_en` text NOT NULL,
  `description_es` text NOT NULL,
  `resumen` text NOT NULL,
  `tags` varchar(255) NOT NULL,
  `type_inventario` int(11) DEFAULT 1,
  `logo_position` varchar(255) DEFAULT 'center',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `categoryId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categoryId` (`categoryId`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `guestId` int(11) DEFAULT NULL,
  `saleId` int(11) DEFAULT NULL,
  `amount` float NOT NULL,
  `paymentMethod` varchar(50) NOT NULL DEFAULT 'efectivo',
  `paymentDate` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pendiente',
  `notes` varchar(250) DEFAULT NULL,
  `zipcode` varchar(250) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `guestId` (`guestId`),
  KEY `saleId` (`saleId`),
  CONSTRAINT `receipts_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `receipts_ibfk_2` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `receipts_ibfk_3` FOREIGN KEY (`saleId`) REFERENCES `sales` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retry_queue`
--

DROP TABLE IF EXISTS `retry_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retry_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único del job de retry',
  `saleId` int(11) NOT NULL COMMENT 'ID de la venta a reintentar',
  `attemptCount` int(11) NOT NULL DEFAULT 0 COMMENT 'Número de intentos realizados',
  `maxAttempts` int(11) NOT NULL DEFAULT 3 COMMENT 'Máximo de intentos permitidos',
  `nextRetryAt` datetime DEFAULT NULL COMMENT 'Fecha/hora del próximo intento',
  `status` enum('pending','processing','resolved','failed','cancelled') NOT NULL DEFAULT 'pending' COMMENT 'Estado actual del job',
  `errorType` enum('temporal','recoverable','critical','unknown') NOT NULL COMMENT 'Clasificación del error',
  `errorCode` varchar(100) DEFAULT NULL COMMENT 'Código específico del error (ej: NETWORK_ERROR, ADDRESS_INVALID)',
  `errorMessage` text DEFAULT NULL COMMENT 'Mensaje de error original',
  `errorData` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Datos adicionales del error (stack, response, etc.)' CHECK (json_valid(`errorData`)),
  `lastError` text DEFAULT NULL COMMENT 'Último error registrado',
  `retryHistory` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Historial de todos los intentos con timestamps y resultados' CHECK (json_valid(`retryHistory`)),
  `resolvedAt` datetime DEFAULT NULL COMMENT 'Fecha/hora de resolución exitosa',
  `cancelledAt` datetime DEFAULT NULL COMMENT 'Fecha/hora de cancelación manual',
  `cancelledBy` varchar(100) DEFAULT NULL COMMENT 'Usuario que canceló el job (admin email)',
  `cancelReason` text DEFAULT NULL COMMENT 'Razón de cancelación',
  `priority` int(11) NOT NULL DEFAULT 0 COMMENT 'Prioridad del job (0=normal, 1=alta, -1=baja)',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Datos adicionales del contexto (customer, amount, etc.)' CHECK (json_valid(`metadata`)),
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_retry_queue_sale` (`saleId`),
  KEY `idx_retry_queue_status` (`status`),
  KEY `idx_retry_queue_next_retry` (`nextRetryAt`),
  KEY `idx_retry_queue_error_type` (`errorType`),
  KEY `idx_retry_queue_processing` (`status`,`nextRetryAt`),
  CONSTRAINT `retry_queue_ibfk_1` FOREIGN KEY (`saleId`) REFERENCES `sales` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Cola de reintentos para órdenes fallidas con backoff exponencial';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retry_queue`
--

LOCK TABLES `retry_queue` WRITE;
/*!40000 ALTER TABLE `retry_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `retry_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_requests`
--

DROP TABLE IF EXISTS `return_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `saleId` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `guestId` varchar(255) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `adminNotes` text DEFAULT NULL,
  `resolution` text DEFAULT NULL,
  `refundAmount` double DEFAULT NULL,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `saleId` (`saleId`),
  KEY `userId` (`userId`),
  CONSTRAINT `return_requests_ibfk_1` FOREIGN KEY (`saleId`) REFERENCES `sales` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `return_requests_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_requests`
--

LOCK TABLES `return_requests` WRITE;
/*!40000 ALTER TABLE `return_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `return_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `saleDetailId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `productId` (`productId`),
  KEY `saleDetailId` (`saleDetailId`),
  KEY `userId` (`userId`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`saleDetailId`) REFERENCES `sale_details` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_addresses`
--

DROP TABLE IF EXISTS `sale_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `surname` varchar(250) NOT NULL,
  `pais` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `referencia` varchar(250) DEFAULT NULL,
  `ciudad` varchar(250) NOT NULL,
  `region` varchar(250) NOT NULL,
  `telefono` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `nota` varchar(255) DEFAULT NULL,
  `zipcode` varchar(250) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `saleId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `saleId` (`saleId`),
  CONSTRAINT `sale_addresses_ibfk_1` FOREIGN KEY (`saleId`) REFERENCES `sales` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_addresses`
--

LOCK TABLES `sale_addresses` WRITE;
/*!40000 ALTER TABLE `sale_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_details`
--

DROP TABLE IF EXISTS `sale_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_discount` int(11) NOT NULL DEFAULT 1,
  `discount` float DEFAULT 0,
  `cantidad` int(11) NOT NULL,
  `code_cupon` varchar(255) DEFAULT NULL,
  `code_discount` varchar(255) DEFAULT NULL,
  `type_campaign` int(11) DEFAULT NULL,
  `price_unitario` float NOT NULL,
  `subtotal` float NOT NULL,
  `total` float NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `saleId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `variedadId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `saleId` (`saleId`),
  KEY `productId` (`productId`),
  KEY `variedadId` (`variedadId`),
  CONSTRAINT `sale_details_ibfk_1` FOREIGN KEY (`saleId`) REFERENCES `sales` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sale_details_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sale_details_ibfk_3` FOREIGN KEY (`variedadId`) REFERENCES `variedades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_details`
--

LOCK TABLES `sale_details` WRITE;
/*!40000 ALTER TABLE `sale_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_payment` varchar(255) DEFAULT 'EUR',
  `method_payment` varchar(50) NOT NULL,
  `n_transaction` varchar(200) NOT NULL,
  `total` float NOT NULL,
  `currency_total` varchar(50) DEFAULT 'EUR',
  `price_dolar` float DEFAULT 0,
  `minDeliveryDate` date DEFAULT NULL,
  `maxDeliveryDate` date DEFAULT NULL,
  `stripeSessionId` varchar(255) DEFAULT NULL,
  `printfulOrderId` varchar(255) DEFAULT NULL,
  `printfulStatus` varchar(255) DEFAULT NULL,
  `printfulUpdatedAt` datetime DEFAULT NULL,
  `trackingNumber` varchar(100) DEFAULT NULL,
  `trackingUrl` varchar(500) DEFAULT NULL,
  `carrier` varchar(100) DEFAULT NULL,
  `shippedAt` datetime DEFAULT NULL,
  `trackingToken` varchar(32) NOT NULL COMMENT 'Token único para acceso público al tracking',
  `errorMessage` text DEFAULT NULL,
  `syncStatus` enum('pending','failed','shipped','canceled','fulfilled') DEFAULT 'pending',
  `completedAt` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `guestId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trackingToken` (`trackingToken`),
  KEY `userId` (`userId`),
  KEY `guestId` (`guestId`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`guestId`) REFERENCES `guests` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipments`
--

DROP TABLE IF EXISTS `shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `saleId` int(11) NOT NULL,
  `printfulShipmentId` varchar(255) DEFAULT NULL,
  `carrier` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `trackingNumber` varchar(255) DEFAULT NULL,
  `trackingUrl` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `shippedAt` datetime DEFAULT NULL,
  `deliveredAt` datetime DEFAULT NULL,
  `returnedAt` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `saleId` (`saleId`),
  CONSTRAINT `shipments_ibfk_1` FOREIGN KEY (`saleId`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipments`
--

LOCK TABLES `shipments` WRITE;
/*!40000 ALTER TABLE `shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `subtitle` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `position` varchar(50) NOT NULL DEFAULT 'middle-left',
  `link` varchar(250) NOT NULL,
  `imagen_mobile` varchar(250) NOT NULL,
  `imagen_desktop` varchar(250) NOT NULL,
  `state` int(11) DEFAULT 1,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sliders`
--

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `surname` varchar(250) DEFAULT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `avatar` varchar(250) DEFAULT NULL,
  `state` int(11) DEFAULT 1,
  `phone` varchar(20) DEFAULT NULL,
  `birthday` varchar(20) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin',NULL,'admin@admin.com','$2a$10$p/5GrZ61IW/2ifkYiPwpPu1AQlnXeDuHobWTTLTi.07zHE8Sbqe32',NULL,1,'',NULL,NULL,'2025-12-12 09:48:49','2025-12-12 09:48:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variedades`
--

DROP TABLE IF EXISTS `variedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variedades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `sync_product_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `synced` tinyint(1) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `main_category_id` int(11) DEFAULT NULL,
  `warehouse_product_id` int(11) DEFAULT NULL,
  `warehouse_product_variant_id` int(11) DEFAULT NULL,
  `retail_price` varchar(255) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `productId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `productId` (`productId`),
  CONSTRAINT `variedades_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variedades`
--

LOCK TABLES `variedades` WRITE;
/*!40000 ALTER TABLE `variedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `variedades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wishlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_discount` int(11) DEFAULT 1,
  `discount` float DEFAULT 0,
  `cantidad` int(11) NOT NULL,
  `code_cupon` varchar(255) DEFAULT NULL,
  `code_discount` varchar(255) DEFAULT NULL,
  `price_unitario` varchar(255) NOT NULL,
  `subtotal` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `variedadId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `productId` (`productId`),
  KEY `variedadId` (`variedadId`),
  CONSTRAINT `wishlists_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wishlists_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wishlists_ibfk_3` FOREIGN KEY (`variedadId`) REFERENCES `variedades` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlists`
--

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-12 10:49:23
